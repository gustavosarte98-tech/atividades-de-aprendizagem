const displayTestimonyVideoModal = (videoId) => {
  const testimonyModal = document.querySelector(`.video_modal.${videoId}`);
  testimonyModal.style.display = "flex";

  const body = document.querySelector("body");
  body.style.overflow = "hidden";
};

const closeTestimonyVideoModal = (videoId) => {
  const testimonyModal = document.querySelector(`.video_modal.${videoId}`);
  testimonyModal.style.display = "none";

  const body = document.querySelector("body");
  body.style.overflow = "auto";
};

let xPos = 0;

gsap
  .timeline()
  .set(dragger, { opacity: 0 }) //make the drag layer invisible
  .set(ring, { rotationY: 180 }) //set initial rotationY so the parallax jump happens off screen
  .set(".img", {
    // apply transform rotations to each image
    rotateY: (i) => i * -36,
    transformOrigin: "50% 50% 500px",
    z: -500,
    backgroundImage: (i) => `url('images/testimonies/${i + 1}.jpg')`,
    backfaceVisibility: "hidden",
  })
  .from(".img", {
    duration: 1.5,
    y: 200,
    opacity: 0,
    stagger: 0.1,
    ease: "expo",
  });

Draggable.create(dragger, {
  onDragStart: (e) => {
    if (e.touches) e.clientX = e.touches[0].clientX;
    xPos = Math.round(e.clientX);
  },

  onDrag: (e) => {
    if (e.touches) e.clientX = e.touches[0].clientX;

    gsap.to(ring, {
      rotationY: "-=" + ((Math.round(e.clientX) - xPos) % 360),
    });

    xPos = Math.round(e.clientX);
  },

  onDragEnd: () => {
    // gsap.to(ring, { rotationY: Math.round(gsap.getProperty(ring,'rotationY')/36)*36 }) // move to nearest photo...at the expense of the inertia effect
    gsap.set(dragger, { x: 0, y: 0 }); // reset drag layer
  },
});

const reservedRights = document.querySelector(".reserved_rights");
reservedRights.innerHTML = `TODOS OS DIREITOS RESERVADOS – ATIVIDADES ANOS INICIAIS Ⓡ 2020 – ${new Date().getFullYear()}`;

const todayOffer = document.querySelector(".value_today");
todayOffer.innerHTML = `Valor Válido e Garantido para hoje ${new Date().toLocaleDateString()}`;

const secondaryBuyButton = document.querySelector(".buy_now_button");
const floatingBuyButton = document.querySelector(".floating_buy");

const onScroll = (e) => {
  function isInViewport(el) {
    const rect = el.getBoundingClientRect();
    return (
      rect.top >= 0 &&
      rect.left >= 0 &&
      rect.bottom <=
        (window.innerHeight || document.documentElement.clientHeight) &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  }

  if ( isInViewport(secondaryBuyButton))
    floatingBuyButton.style.display = "none";
  if (
    !isInViewport(secondaryBuyButton) &&
    window.innerWidth < 900
  )
    floatingBuyButton.style.display = "flex";
};

document.addEventListener("scroll", onScroll);

const quickDescription = document.querySelector(".book_text");
if (window.innerWidth < 900)
  quickDescription.innerHTML =
    "Arraste a animação abaixo para o lado para visualizar as atividades do material";

const toogleFaq = (div) => {
  const asnwerHeight =
    div.firstChild.nextSibling.nextElementSibling.clientHeight;
  if (div.clientHeight === 45)
    return (div.style.height = `${asnwerHeight + 45}px`);

  return (div.style.height = "25px");
};

const downloadTag = document.querySelector('.magent_tag')
const tagContent = downloadTag.firstChild.nextSibling

setInterval(() => {
  tagContent.style.opacity = 0
  setTimeout(() => {
    tagContent.style.opacity = 1
    tagContent.innerHTML = 'Baixe aqui'

    setTimeout(() => {
      tagContent.style.opacity = 0
      
      setTimeout(() => {
        tagContent.innerHTML = 'Amostra em HD'
        tagContent.style.opacity = 1
      }, 500)
    }, 1000)
  }, 500)
}, 3000)


